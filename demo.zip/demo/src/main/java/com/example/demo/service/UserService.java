package com.example.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.dto.UserVo;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

@Transactional

public interface UserService {
	
	
	
    public List<UserVo> listAllUser();
    public String addUser(UserVo vo);
    public String updateUser(UserVo vo);
    public String deleteUser(Integer Id);

    
}
