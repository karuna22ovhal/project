package com.example.demo.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.UserVo;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserServiceImpl  implements UserService {
	
	@Autowired 
	UserRepository userRepo;

	@Override
	public List<UserVo> listAllUser() {
		List<User> userList=userRepo.findByUserStatus("A");
		List <UserVo> voList=new ArrayList<UserVo>();
		for(User user:userList) {
			UserVo vo=new UserVo();
			vo.setId(user.getId());
			vo.setUserName(user.getUserName());
		     vo.setEmail(user.getEmail());
			vo.setUserMob(user.getUserMob());
			voList.add(vo);
			
		}
		// TODO Auto-generated method stub
		return voList;
	}

	@Override
	public String addUser(UserVo vo) {
		
		User user=new User();
		user.setUserName(vo.getUserName());
		user.setEmail(vo.getEmail());
		user.setUserMob(vo.getUserMob());
		user.setUserStatus("A");
		user.setCreateDateTime(new Date());
		
		userRepo.save(user);
		return "success";
	}

	@Override
	public String updateUser(UserVo vo) {
		Optional<User> findById = userRepo.findById(vo.getId());
		if(findById.isPresent()) {
			User user=findById.get();
			user.setUserName(vo.getUserName());
			user.setEmail(vo.getEmail());
			user.setUserMob(vo.getUserMob());
			user.setUpdtDateTime(new Date());
			userRepo.save(user);
		}
		
		return "updatesuccess";
	}

	@Override
	public String deleteUser(Integer Id) {
		Optional<User> findById = userRepo.findById(Id);
		if(findById.isPresent()) {
			User user=findById.get();
			user.setUserStatus("D");
			user.setUpdtDateTime(new Date());
			userRepo.save(user);
		}
		return "deletesuccess";
	}

	
	

}
