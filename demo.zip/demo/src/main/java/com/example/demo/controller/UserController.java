package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.UserVo;
import com.example.demo.entity.User;
import com.example.demo.service.UserService;

@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userservice;

	@PostMapping("/insertUser")
	@ResponseBody
	public String addUser(@RequestBody UserVo vo) {

		return userservice.addUser(vo);

	}

	@GetMapping("/getUser")
	@ResponseBody
	public List<UserVo> getUser(String UserVo) {

		return userservice.listAllUser();

	}
	
	
	@PostMapping("/updateUser")
	@ResponseBody
	public String updateUser(@RequestBody UserVo vo) {
		
		
		return userservice.updateUser(vo);
		
	    }
	
	@GetMapping("/deleteUser")
	@ResponseBody
	public String deleteUser(@RequestParam  Integer Id ) {
		
		
		return userservice.deleteUser(Id);
		
	    }
	
	
	

}
