package com.example.demo.dto;

import javax.persistence.Column;

public class UserVo {
	 
		private Integer Id;
		private String userName;
	    private String email;
		private String userMob;
		public Integer getId() {
			return Id;
		}
		public void setId(Integer id) {
			Id = id;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getUserMob() {
			return userMob;
		}
		public void setUserMob(String userMob) {
			this.userMob = userMob;
		}
		public String getUserStatus() {
			return userStatus;
		}
		public void setUserStatus(String userStatus) {
			this.userStatus = userStatus;
		}
		private String userStatus;
		

}
